fetch('https://fakestoreapi.com/products')
  .then(resposta => resposta.json())
  .then(dado => {
    const metade = dado.slice(0,10);
    const tabela = document.getElementById('product-table-body');
    
    for (let i = 0; i < metade.length; i++) {
      const produto = metade[i];



      const quantidade = Math.floor(Math.random() * 20) + 1; // 1 a 20
      const promocaoPercent = [0, 5, 10, 15, 20][Math.floor(Math.random() * 5)]; // 0% a 20%
      const precoComDesconto = produto.price * (1 - promocaoPercent / 100);
      const total = precoComDesconto * quantidade;



      tabela.innerHTML += `
        <tr>
          <td>${produto.id}</td>
          <td>${produto.title}</td>
          <td>$${produto.price.toFixed(2)}</td>
          <td>${produto.category}</td>
          <td><img src="${produto.image}" alt="Imagem" style="width: 50px; height: auto;"></td>
          <td>${quantidade}</td>
          <td>${promocaoPercent}%</td>
          <td>$${total.toFixed(2)}</td>
        </tr>
      `;
    }
  })
  .catch(error => {
    console.error('Erro ao carregar os produtos:', error);
  });