const btn = document.querySelector("#acessar");

btn.addEventListener("click", () => {
    window.location.href = "./html/produtos.html";
});