fetch('https://fakestoreapi.com/products')
  .then(resposta => resposta.json())
  .then(dado => {
    const metade = dado.slice(0,10);
    const tabela = document.getElementById('product-table-body');
    
    for (let i = 0; i < metade.length; i++) {
      const produto = metade[i];
      tabela.innerHTML += `
        <tr>
          <td>${produto.id}</td>
          <td>${produto.title}</td>
          <td>$${produto.price.toFixed(2)}</td>
          <td>${produto.category}</td>
          <td><img src="${produto.image}" alt="Imagem" style="width: 50px; height: auto;"></td>
        </tr>
      `;
    }
  })
  .catch(error => {
    console.error('Erro ao carregar os produtos:', error);
  });